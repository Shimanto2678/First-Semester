public class TuitionDoubling {
    public static void main(String[] args) {
        double tuition = 10000; 
        double target = 2 * tuition;
        double rate = 0.07;
        int years = 0;

        while (tuition < target) {
            tuition += tuition * rate; 
            years++; 
        }

        System.out.println("Tuition will double in " + years + " years.");
    }
}